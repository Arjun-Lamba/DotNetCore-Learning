﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DepartmentalData.SeedData
{
    /// <summary>
    /// This class work for set default value when appliation run first time
    /// </summary>
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new StoreAppContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<StoreAppContext>>()))
            {
                context.Database.EnsureCreated();
                // Look for any Department.
                if (context.Departments.Any())
                {
                    return;   // DB has been seeded
                }
                //Add defult department
                context.Departments.AddRange(
                    new Entity.Department
                    {
                        Name = "Default Department",
                        Description = "Contains many items",
                        IsActive = true
                        
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
