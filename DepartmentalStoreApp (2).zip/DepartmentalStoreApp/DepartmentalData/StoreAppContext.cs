﻿using DepartmentalData.Entity;
using Microsoft.EntityFrameworkCore;

namespace DepartmentalData
{
    /// <summary>
    /// Add new entity in dbcontext
    /// </summary>
    public class StoreAppContext : DbContext
    {
        public StoreAppContext(DbContextOptions<StoreAppContext> options) : base(options)
        {
        }
        public DbSet<Department> Departments { get; set; }
    }
}