﻿using DepartmentalData.Entity;

namespace DepartmentalStoreApp.Models
{
    public static class Extension
    {
        /// <summary>
        /// This extension method work for convert vmDepartment model to Departmet 
        /// </summary>
        /// <returns>Department</returns>
        public static Department FromVm(this VmDepartment g)
        {
            Department department = new Department();
            if (g != null)
            {
                department.Name = g.Name;
                department.Description = g.Description;
                department.IsActive = g.IsActive;
                department.ModifiedOn = g.UpdatedOn;
                //department.CreatedOn = g.CreatedOn;
                department.DepartmentId = g.DepartmentId;
            }
            return department;
        }
        /// <summary>
        /// This extension method work for convert Departmet to vmDepartment model  
        /// </summary>
        /// <returns>VmDepartment</returns>
        public static VmDepartment ToVm(this Department g)
        {
            VmDepartment department = new VmDepartment();
            if (g != null)
            {
                department.Name = g.Name;
                department.Description = g.Description;
                department.IsActive = g.IsActive;
                department.UpdatedOn = g.ModifiedOn;
                department.CreatedOn = g.CreatedOn;
                department.DepartmentId = g.DepartmentId;
            }
            return department;
        }
        /// <summary>
        /// This extension method work for convert Departmet list to vmDepartment model list  
        /// </summary>
        /// <returns>List VmDepartment </returns>
        public static List<VmDepartment> ToListVm(this List<Department> li)
        {
            var vmDe = li.Select(a => new VmDepartment { Name = a.Name, DepartmentId = a.DepartmentId, IsActive = a.IsActive, Description = a.Description, CreatedOn = a.CreatedOn, UpdatedOn = a.ModifiedOn }).ToList();
            return vmDe;
        }
    }
}
