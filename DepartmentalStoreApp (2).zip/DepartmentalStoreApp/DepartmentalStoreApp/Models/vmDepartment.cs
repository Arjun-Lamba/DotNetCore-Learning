﻿using System.ComponentModel.DataAnnotations;

namespace DepartmentalStoreApp.Models
{
    public class VmDepartment
    {
        public Guid DepartmentId { get; set; }
        [Required(ErrorMessage = "Name is required")]
        public string? Name { get; set; }
        [Required(ErrorMessage = "Description is required")]
        public string? Description { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}
