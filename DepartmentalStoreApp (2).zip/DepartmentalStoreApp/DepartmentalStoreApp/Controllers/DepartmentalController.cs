﻿using DepartmentalStoreApp.InterfaceRepository;
using DepartmentalStoreApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DepartmentalStoreApp.Controllers
{
    public class DepartmentalController : Controller
    {
        private readonly IDepartmentRepository _departmentRepository;
        private readonly ILogger<DepartmentalController> _logger;
        public DepartmentalController(ILogger<DepartmentalController> logger, IDepartmentRepository departmentRepository)
        {
            _logger = logger;
            _departmentRepository = departmentRepository;
        }
        // GET: DepartmentalController
        /// <summary>
        /// This action work for for show all active department 
        /// </summary>
        /// <returns>list of department</returns>
        public ActionResult Index()
        {
            List<VmDepartment> departments = new List<VmDepartment>();
            try
            {
                departments = _departmentRepository.GetAllDepartment();
                _logger.LogInformation("Success : get Department list");
            }
            catch (Exception ex)
            {
                _logger.LogError("Index :" + ex.Message);
            }
            return View(departments);
        }


        // GET: DepartmentalController/Create
        public ActionResult Create()
        {
            return View(new VmDepartment() { IsActive = true });
        }

        // POST: DepartmentalController/Create
        /// <summary>
        /// This action work for save department in database 
        /// </summary>
        /// <param name="collection">Department propertys</param>
        /// <returns>After success return to list of department</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(VmDepartment collection)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation("Create Department: model not valid");
                return View(collection);

            }
            try
            {
                _departmentRepository.AddDepartment(collection);
                _logger.LogInformation("Create Department: Department add successfuly");
            }
            catch (Exception ex)
            {
                _logger.LogError("Create Department: " + ex.Message);
            }
            return RedirectToAction(nameof(Index));

        }

        // GET: DepartmentalController/Edit/5
        /// <summary>
        /// Get department by id
        /// </summary>
        /// <param name="id">Department id</param>
        /// <returns>view</returns>
        public ActionResult Edit(Guid id)
        {
            var vmDepart = _departmentRepository.GetDepartment(id);
            return View(vmDepart);
        }

        // POST: DepartmentalController/Edit
        /// <summary>
        /// This action work for update department
        /// </summary>
        /// <param name="collection">Department propertys</param>
        /// <returns>After update department return to list</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(VmDepartment collection)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation("Edit : Model not vaid");
                return View(collection);
            }
            try
            {
                _departmentRepository.UpdateDepartment(collection);
                _logger.LogInformation("Edit : Department update successfuly");
            }
            catch (Exception ex)
            {
                _logger.LogError("Edit : " + ex.Message);
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: DepartmentalController/Delete/id
        /// <summary>
        /// This action work for delete department
        /// </summary>
        /// <param name="id">Department id</param>
        /// <returns>After Delete department return to list</returns>
        public ActionResult Delete(Guid id)
        {
            try
            {
                _departmentRepository.DeleteDepartment(id);
                _logger.LogInformation("Delete : Department delete successfuly");
            }
            catch (Exception ex)
            {
                _logger.LogError("Delete : " + ex.Message);
            }
            return RedirectToAction(nameof(Index));
        }


    }
}
