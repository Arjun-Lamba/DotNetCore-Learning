﻿using DepartmentalStoreApp.Models;

namespace DepartmentalStoreApp.InterfaceRepository
{
    public interface IDepartmentRepository
    {
        /// <summary>
        /// Method declarations for add department 
        /// </summary>
        /// <param name="createVm">model of department</param>
        /// <returns></returns>
        bool AddDepartment(VmDepartment createVm);
        /// <summary>
        /// Method declarations for delete department 
        /// </summary>
        /// <param name="id">Contain Department id</param>
        /// <returns></returns>
        bool DeleteDepartment(Guid id);
        /// <summary>
        /// Method declarations for Update department 
        /// </summary>
        /// <param name="updateVm">model of department</param>
        /// <returns></returns>
        bool UpdateDepartment(VmDepartment updateVm);
        /// <summary>
        /// Method declarations for get active department list
        /// </summary>
        /// <returns></returns>
        List<VmDepartment> GetAllDepartment();
        /// <summary>
        /// Method declarations for get department by department id
        /// </summary>
        /// <param name="id">Department id</param>
        /// <returns></returns>
        VmDepartment GetDepartment(Guid id);


    }
}
