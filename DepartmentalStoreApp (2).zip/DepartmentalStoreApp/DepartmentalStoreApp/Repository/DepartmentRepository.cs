﻿using DepartmentalData;
using DepartmentalStoreApp.InterfaceRepository;
using DepartmentalStoreApp.Models;

namespace DepartmentalStoreApp.Repository
{
    /// <summary>
    /// This is Department Repository its contains all function implimention 
    /// </summary>
    public class DepartmentRepository : IDepartmentRepository
    {
        private readonly StoreAppContext appContext;
        public DepartmentRepository(StoreAppContext appContext)
        {
            this.appContext = appContext;
        }
        // this method work for add department
        public bool AddDepartment(VmDepartment createVm)
        {
            bool result = false;
            try
            {
                var department = createVm.FromVm();
                appContext.Add(department);
                appContext.SaveChanges();
                result = true;
            }
            catch (Exception)
            {

            }
            return result;
        }
        //This method work for delete department by department id
        public bool DeleteDepartment(Guid id)
        {
            bool result = false;
            try
            {
                var dep = appContext.Departments.Find(id);
                if (dep != null)
                {
                    appContext.Departments.Remove(dep);
                    appContext.SaveChanges();
                    result = true;
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        //This method work for get all active department list from database
        public List<VmDepartment> GetAllDepartment()
        {
            var list = appContext.Departments.Where(a=>a.IsActive).ToList();
            return list.ToListVm();
        }
        //This method work for update department
        public bool UpdateDepartment(VmDepartment updateVm)
        {
            bool result = false;
            try
            {
                var updateVal = updateVm.FromVm();
                updateVal.ModifiedOn = DateTime.Now;
                appContext.Departments.Update(updateVal);
                appContext.SaveChanges();
                result = true;
            }
            catch (Exception) { }
            return result;
        }
        //This method work for get Department by Department id
        public VmDepartment GetDepartment(Guid id)
        {
            var dep = appContext.Departments.Find(id);
            return dep.ToVm();
        }
    }
}
